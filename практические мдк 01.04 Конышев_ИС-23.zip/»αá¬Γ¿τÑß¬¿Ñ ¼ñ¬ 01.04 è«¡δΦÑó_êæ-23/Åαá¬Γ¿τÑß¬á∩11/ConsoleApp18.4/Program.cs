﻿using System;
using System.Threading;

namespace ConsoleApp18._4
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 8; i++)
            {
                Reader reader = new Reader(i);
            }
            Console.ReadLine();
            Console.WriteLine("Животные наелись");
        }
    }
    class Reader
    {
        // создаем семафор
        static Semaphore sem = new Semaphore(3, 4);
        Thread myThread;
        int count = 1;

        public Reader(int i)
        {
            myThread = new Thread(Read);
            myThread.Name = $"Животное №{i}";
            myThread.Start();
        }

        public void Read()
        { Random random = new Random();
            uint satiety;
            while (count > 0)
            {
                sem.WaitOne();

                Console.WriteLine($"{Thread.CurrentThread.Name} приходит на поляну");
                Thread.Sleep(1000);
               Console.WriteLine($"{Thread.CurrentThread.Name} нюхает");
                if (random.Next(0, 6) < 3)
                {
                    satiety = 0;
                         Console.WriteLine($"{Thread.CurrentThread.Name} ест (сытость {satiety}%)");
                        Thread.Sleep(1000);
                    satiety += 50;
                        Console.WriteLine($"{Thread.CurrentThread.Name} cытость {satiety}%");
                        Thread.Sleep(2000);
                    satiety += 50;
                    Console.WriteLine($"{Thread.CurrentThread.Name} cытость {satiety}%");
                    Thread.Sleep(2000);

                }

                else Console.WriteLine($"{Thread.CurrentThread.Name} не ест");
                Thread.Sleep(3000);

                Console.WriteLine($"{Thread.CurrentThread.Name} покидает поляну");

                sem.Release();

                count--;
                Thread.Sleep(1000);
            } 
        } 
    }
}


