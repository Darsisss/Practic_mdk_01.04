﻿using LibraryPrac5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrac5
{
    class Program:BrainValidationAttribute
    {
        static void Main(string[] args)
        {
            
            Daemon[] daemons = new Daemon[]
            {
                new Daemon("Фарк",1),
                new Daemon("Ларк",10),
                new Daemon("Арк",15),
                new Daemon("Муркх",7),
                new Daemon("Йорг",76),
                new Daemon("Арм",2),
            };
            Daemon[] daemonsValid = new Daemon[daemons.Length];
            foreach (var daemon in daemons)
            {
                int i=0;
                if (ValidateDaemon(daemon) == true)
                    daemonsValid[i] = daemon;
                ++i;
            }

            foreach (var daemon in daemonsValid)
                Console.WriteLine(daemon);
            Console.ReadLine();
        }
    }
}
