﻿using System;

namespace LibraryPrac5
{
    public class Daemon : Monster
    {
        [BrainValidation(Brain =3)]
        int brain;
         public int Brain { get; set; }

        public Daemon() => brain = 1;

        public Daemon(string name, int brain) : base(name) => this.brain = brain;

        public Daemon(int health, int ammo, string name, int brain) : base(health, ammo, name)
            => this.brain = brain;

        override public void Passport()
        {
            Console.WriteLine("Daemon {0} \t health = {1} ammo = {2} brain = {3}",
            Name, Health, Ammo, brain);
        }
        public void Think()
        {
            Console.Write(Name + " is");
            for (int i = 0; i < brain; ++i) Console.Write(" thinking");
            Console.WriteLine("...");
        }

        public override string ToString()
            => $"Daemon\n Name={Name}\n Brain={brain}\n Ammo={Ammo}\n Health={Health}";
    }

}
