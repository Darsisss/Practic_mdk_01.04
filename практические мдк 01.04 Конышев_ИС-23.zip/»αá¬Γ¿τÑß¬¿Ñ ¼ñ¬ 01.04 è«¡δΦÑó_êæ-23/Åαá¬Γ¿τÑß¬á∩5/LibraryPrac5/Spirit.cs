﻿namespace LibraryPrac5
{
    public abstract class Spirit
    {
        public abstract void Passport();
    }
}
