﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryPrac5
{
   public class BrainValidationAttribute : System.Attribute
    {
        public int Brain { get; set; }

        public BrainValidationAttribute() { }

        public BrainValidationAttribute(int brain)
        {
            Brain = brain;
        }

     public static bool ValidateDaemon(Daemon daemon)
        {
            Type type = typeof(Daemon);
            object[] attributes = type.GetCustomAttributes(false);
            foreach (BrainValidationAttribute attr in attributes)
            {
                if (daemon.Brain >= attr.Brain)
                    return true;
                else return false;
            }
            return true;
        }
    }
}
